const jwt = require("jsonwebtoken");

function signToken(user) {
  return jwt.sign(
    { sub: String(user.id), username: user.username },
    process.env.JWT_SECRET,
    { expiresIn: "7d", issuer: "nexo-backend", audience: "nexo-app" }
  );
}

function verifyToken(token) {
  return jwt.verify(token, process.env.JWT_SECRET, {
    issuer: "nexo-backend",
    audience: "nexo-app"
  });
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Authentication required" });

  try {
    req.auth = verifyToken(token);
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

module.exports = { signToken, verifyToken, requireAuth };
