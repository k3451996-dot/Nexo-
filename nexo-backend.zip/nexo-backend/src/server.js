require("dotenv").config();

const http = require("http");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const { Server } = require("socket.io");
const { pool, initDb } = require("./db");
const { signToken, verifyToken, requireAuth } = require("./auth");

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error("JWT_SECRET must be set and contain at least 32 characters.");
}

const app = express();
const server = http.createServer(app);
const allowedOrigins = (process.env.CORS_ORIGIN || "*").split(",").map(x => x.trim());

const corsOptions = {
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error("Origin not allowed by CORS"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Authorization"]
};

app.use(helmet());
app.use(cors(corsOptions));
app.use(express.json({ limit: "32kb" }));
app.use("/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const io = new Server(server, {
  cors: {
    origin: allowedOrigins.includes("*") ? "*" : allowedOrigins,
    methods: ["GET", "POST"]
  }
});

app.get("/", (_req, res) => {
  res.json({ service: "NEXO Backend", status: "running", health: "/health" });
});

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", database: "connected" });
  } catch {
    res.status(503).json({ status: "error", database: "unavailable" });
  }
});

app.post("/auth/register", async (req, res, next) => {
  try {
    const username = String(req.body.username || "").trim().toLowerCase();
    const displayName = String(req.body.displayName || username).trim();
    const password = String(req.body.password || "");

    if (!/^[a-z0-9_]{3,32}$/.test(username)) {
      return res.status(400).json({ error: "Username must be 3-32 characters: a-z, 0-9, underscore." });
    }
    if (displayName.length < 1 || displayName.length > 48) {
      return res.status(400).json({ error: "Display name must be 1-48 characters." });
    }
    if (password.length < 10 || password.length > 72) {
      return res.status(400).json({ error: "Password must be 10-72 characters." });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO users (username, display_name, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, username, display_name, created_at`,
      [username, displayName, passwordHash]
    );
    const user = result.rows[0];
    res.status(201).json({
      user: { id: user.id, username: user.username, displayName: user.display_name, createdAt: user.created_at },
      token: signToken(user)
    });
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "Username is already taken." });
    next(err);
  }
});

app.post("/auth/login", async (req, res, next) => {
  try {
    const username = String(req.body.username || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const result = await pool.query(
      "SELECT id, username, display_name, password_hash, created_at FROM users WHERE username = $1",
      [username]
    );
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Incorrect username or password." });
    }
    res.json({
      user: { id: user.id, username: user.username, displayName: user.display_name, createdAt: user.created_at },
      token: signToken(user)
    });
  } catch (err) {
    next(err);
  }
});

app.get("/users/me", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id, username, display_name, created_at FROM users WHERE id = $1",
      [req.auth.sub]
    );
    if (!result.rows[0]) return res.status(404).json({ error: "User not found." });
    const user = result.rows[0];
    res.json({ id: user.id, username: user.username, displayName: user.display_name, createdAt: user.created_at });
  } catch (err) {
    next(err);
  }
});

app.get("/users", requireAuth, async (req, res, next) => {
  try {
    const q = String(req.query.q || "").trim().toLowerCase().slice(0, 32);
    if (!q) return res.json({ users: [] });
    const result = await pool.query(
      `SELECT id, username, display_name FROM users
       WHERE username LIKE $1 AND id <> $2
       ORDER BY username LIMIT 20`,
      [`${q}%`, req.auth.sub]
    );
    res.json({ users: result.rows.map(u => ({ id: u.id, username: u.username, displayName: u.display_name })) });
  } catch (err) {
    next(err);
  }
});

app.get("/messages/:userId", requireAuth, async (req, res, next) => {
  try {
    const otherId = Number(req.params.userId);
    const before = req.query.before ? new Date(req.query.before) : null;
    if (!Number.isSafeInteger(otherId) || otherId < 1 || String(otherId) === String(req.auth.sub)) {
      return res.status(400).json({ error: "Invalid userId." });
    }
    const params = [req.auth.sub, otherId];
    let beforeSql = "";
    if (before && !Number.isNaN(before.getTime())) {
      params.push(before.toISOString());
      beforeSql = "AND created_at < $3";
    }
    const result = await pool.query(
      `SELECT id, sender_id, recipient_id, body, created_at
       FROM messages
       WHERE ((sender_id = $1 AND recipient_id = $2) OR (sender_id = $2 AND recipient_id = $1))
       ${beforeSql}
       ORDER BY created_at DESC LIMIT 50`,
      params
    );
    res.json({ messages: result.rows.reverse() });
  } catch (err) {
    next(err);
  }
});

async function saveMessage(senderId, recipientId, body) {
  const result = await pool.query(
    `INSERT INTO messages (sender_id, recipient_id, body)
     SELECT $1, $2, $3
     WHERE EXISTS (SELECT 1 FROM users WHERE id = $2)
     RETURNING id, sender_id, recipient_id, body, created_at`,
    [senderId, recipientId, body]
  );
  return result.rows[0] || null;
}

io.use((socket, next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) return next(new Error("Authentication required"));
    socket.user = verifyToken(token);
    next();
  } catch {
    next(new Error("Invalid or expired token"));
  }
});

io.on("connection", socket => {
  const userId = String(socket.user.sub);
  socket.join(`user:${userId}`);

  socket.on("message:send", async (payload, ack) => {
    try {
      const recipientId = Number(payload && payload.recipientId);
      const body = String(payload && payload.body || "").trim();
      if (!Number.isSafeInteger(recipientId) || recipientId < 1 || String(recipientId) === userId) {
        return typeof ack === "function" && ack({ ok: false, error: "Invalid recipient." });
      }
      if (!body || body.length > 4000) {
        return typeof ack === "function" && ack({ ok: false, error: "Message must be 1-4000 characters." });
      }
      const message = await saveMessage(userId, recipientId, body);
      if (!message) return typeof ack === "function" && ack({ ok: false, error: "Recipient not found." });

      io.to(`user:${userId}`).to(`user:${recipientId}`).emit("message:new", message);
      if (typeof ack === "function") ack({ ok: true, message });
    } catch {
      if (typeof ack === "function") ack({ ok: false, error: "Could not send message." });
    }
  });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error." });
});

const port = Number(process.env.PORT || 10000);

initDb()
  .then(() => {
    server.listen(port, "0.0.0.0", () => {
      console.log(`NEXO backend listening on port ${port}`);
    });
  })
  .catch(err => {
    console.error("Database initialization failed:", err);
    process.exit(1);
  });

process.on("SIGTERM", async () => {
  server.close();
  await pool.end();
  process.exit(0);
});
