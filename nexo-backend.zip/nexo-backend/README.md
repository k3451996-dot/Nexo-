# NEXO Backend

Node.js backend starter for NEXO Messenger. It includes registration, login, user lookup, message history, and real-time messaging over Socket.IO.

## Requirements

- Node.js 20+
- PostgreSQL database
- Render Web Service

## Deploy on Render

1. Upload the contents of this folder to the root of your GitHub repository (the folder containing `package.json`).
2. In Render, create or open a **Web Service** connected to that repository.
3. Set:
   - **Root Directory:** leave blank if `package.json` is in the repository root; otherwise set it to the folder containing `package.json`.
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. Create a PostgreSQL database in Render.
5. Copy its **Internal Database URL** into the Web Service environment variable `DATABASE_URL`.
6. Add `JWT_SECRET` with a long random value (at least 32 characters). Do not put secrets in GitHub.
7. Set `CORS_ORIGIN` to `*` for initial testing. Before public launch, restrict it to trusted origins where applicable.
8. Deploy. Visit `/health`; a successful response should show `{"status":"ok","database":"connected"}`.

If you use `render.yaml`, review the service and database settings in the Render dashboard. The YAML creates a Web Service configuration but does not automatically provision a PostgreSQL database.

## API

Base URL example: `https://YOUR-SERVICE.onrender.com`

### Health
`GET /health`

### Register
`POST /auth/register`
```json
{
  "username": "nexo_user",
  "displayName": "NEXO User",
  "password": "a-long-password"
}
```

### Login
`POST /auth/login`
```json
{
  "username": "nexo_user",
  "password": "a-long-password"
}
```

Both auth endpoints return `{ "user": {...}, "token": "..." }`.

### Current profile
`GET /users/me`
Header: `Authorization: Bearer TOKEN`

### Search users
`GET /users?q=ne`
Header: `Authorization: Bearer TOKEN`

### Message history
`GET /messages/USER_ID`
Header: `Authorization: Bearer TOKEN`

## Socket.IO

Connect with:
```js
import { io } from "socket.io-client";

const socket = io("https://YOUR-SERVICE.onrender.com", {
  auth: { token: accessToken }
});
```

Send:
```js
socket.emit("message:send", {
  recipientId: 2,
  body: "Hello from NEXO"
}, result => console.log(result));
```

Listen:
```js
socket.on("message:new", message => {
  console.log(message);
});
```

The Android/Kotlin client will need a Socket.IO client compatible with the server protocol. Do not send the JWT in a URL query string.

## Important limitations

- This is a starter backend, not a complete Telegram replacement.
- File uploads, push notifications, group chats, read receipts, moderation, account recovery, and end-to-end encryption are not included yet.
- Use HTTPS (Render provides it), keep secrets out of GitHub, and add backups/monitoring before real users depend on the service.
- Render free web services may sleep when idle; availability depends on the selected Render plan.
